// Trigger GitHub Pages redeploy
window.weatherApiKey = "0fd7b16fe667ade38033ebb5c871aab8";
window.weatherLocation = "Phoenix,US";
